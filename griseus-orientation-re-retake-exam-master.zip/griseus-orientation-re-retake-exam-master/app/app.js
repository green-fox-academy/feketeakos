const express = require('express');
const app = express();
const mysql = require('mysql');
app.set('view engine', 'ejs');

app.use(express.urlencoded());
app.use(express.json());
app.use(express.static('static'));

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'password',
  database: 'registration'
});

connection.connect(error => {
  if (error) {
    console.log(`cannot connect to database.`)
    return;
  };
  console.log('connection established.')
})

app.get('/', (req, res) => {
  res.sendFile('index.html', { root: 'views' });
});

app.get('/api/users', (req, res) => {
  const items = `select email, balance from users;`
  connection.query(items, (err, rows) => {
    if (err) {
      res.sendStatus(500);
    } else {
      res.send({ users: rows });
    }
  });
});

app.post('/api/users', (req, res) => {
  const email = req.body.email;
  let password = req.body.password;
  const couponcode = req.body.couponcode;
  connection.query(`select * from users`, (err, rows) => {
    for (let i = 0; i < rows.length; i++) {
      if (rows[i].email === email) {
        res.send({
          message: 'The email you provided is already in use. Please give another email.'
        }); return
      }
    };
    if (err) {
      res.sendStatus(500);
    } else if (!rows[0]) {
      res.sendStatus(400);
    } else if (!email || !password) {
      res.send({
        message: 'Some of the required parameter(s) might be missing.Check.'
      });
    } else {
      function rot13(password) {
        return password.replace(/[A-Z]/gi, c =>
          "NOPQRSTUVWXYZABCDEFGHIJKLMnopqrstuvwxyzabcdefghijklm"[
          "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".indexOf(c)])
      };
      password = rot13(password);
      const data = [email, password, couponcode];
      if (couponcode === 'FIRST100' && rows[101] === undefined || !rows[101]) {
        connection.query('INSERT INTO users VALUES (?, ?, ?), balance = balance + 1000', data, (err, rows) => {
          if (err) {
            res.sendStatus(500);
          } else {
            res.send({
              message: 'Your registration was succesful and coupon code accepted!'
            })
          }
        })
      } else {
        connection.query('INSERT INTO users VALUES (?, ?, ?)', data, (err, rows) => {
          if (err) {
            res.sendStatus(500);
          } else {
            res.sendStatus(201);
            res.send({
              message: 'Your registration was succesful, but your coupon code was invalid!'
            });
          }
        })
      }
    }
  })
});

module.exports = app;