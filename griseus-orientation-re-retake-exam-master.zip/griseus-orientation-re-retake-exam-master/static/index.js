'use strict';
const emailField = document.getElementById('email');
const passwordField = document.getElementById('password');
const couponField = document.getElementById('coupon');
const submitButton = document.getElementById('submit');

const loadData = () => {
  fetch('/api/users')
    .then(response => response.json())
    .then(response => {
      getFirst5(response);
      return response;
    })
};
window.onload = loadData;

function getFirst5(data) {
  const users = data.users;
  for (let i = 0; i < 5; i++) {
    let split = [users[i].email.split('@')];
    for (let j = 0; j < split.length; j++) {
      split[j].pop();
    }
    const newUser = document.createElement('div');
    const select = document.getElementById('registered');
    newUser.innerText = split;
    select.appendChild(newUser);
  }
};

submitButton.addEventListener('click', e => {
  e.preventDefault();
  const email = emailField.value;
  const password = passwordField.value;
  const couponcode = couponField.value;
  if (!email || !password) {
    document.getElementById('error').textContent = 'You must give an email address and a password!';
    return;
  }
  fetch(`/api/users`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      email: email,
      password: password,
      couponcode: couponcode
    })
  })
    .then(response => response.json())
    .then(response => {
      document.getElementById('response').textContent = response.message;
      if (response.message === 'Your registration was succesful!') {
        document.querySelector('form').reset();
      }
      return;
    })
});
