
# License plates

## Highlights

- It has a simple frontend which can:
  - search full or *partial* licence plate matches
  - it can filter to a sub category of plates (like police cars only)
  - it can start a new search by clicking on the make of the car
- The backend validates if the licence plate is valid query
- You have to create two endpoints

## Database

Feel free to use the provided SQL file [for MySQL](assets/backend-license-plates.sql).

## Frontend

- You should create only one template for the exercise

### The form

- You should display a simple form to query a database, _don't waste time with
  design_
  - Create an input field in which the user can enter a licence plate, like
    `HMZ-140` or any part of the license plate (like `MZ-1`)
  - Create a button with the text `Search`
    - Clicking on the button should send a `get` request to the backend
    - The frontend should display the results from the DB.
  - Add two links next to the form:
    - `Police cars only` - Filter for cars only starting with the `RB` prefix
    - `Diplomats only` - Filter for cars only staring with `DT` prefix
    - if any of them is clicked list only the cars with the defined prefixed
      license plate

### Search results

- Display the results from the database in a HTML `<table>` the following format
  for the query `HMZ`

```text
| Licence plate | Brand   | Model | Color | Year |
| HMZ-140       | [Audi]  | A8    | red   | 2016 |
| HMZ-555       | [BMW]   | Z4    | pink  | 2011 |
```

- The app can display multiple rows of results since it should match partial
  queries as well
- Clicking on the `brand` field should display all cars with the same type
  - So clicking on "Audi" should restart the search and list all cars from the
    database regardless of the original query that resulted with this list
- If the user submits an invalid licence plate, like `HMZ-@#5` then display an
  error message instead of the table
  - Display message: `Sorry, the submitted licence plate is not valid`

## Backend

### Checking input data

You should check all input submitted by the user (through the search form)!

- Only allow alphanumeric characters from the user: `[A-Z]`, `[0-9]` and the `-`
  dash symbol

For the licence plate lookup only:

- Maximum length of the query is 7 characters

If the submitted data doesn't match any above criteria, display the error
message detailed above (in the frontend part).

### Endpoints

You should create three endpoints:

#### GET `/search`

The licence plate data and the limiting filter options should be passed via
query string.

Example query:

`http://localhost:8080/search?q=HMZ-140`
`http://localhost:8080/search?police=1`

- use the `police` parameter to filter for police cars
- use the `diplomat` parameter to filter for diplomat cars

The endpoint should render an HTML displaying the results.

#### GET `/search/{brand}`

This endpoint should return all the cars with the provided `brand`

Example query:

`http://localhost:8080/search/audi`

The endpoint should render an HTML displaying the results.

#### GET `/api/search/{brand}`

This endpoint should return all the cars with the provided `brand`

Example query:

`http://localhost:8080/api/search/audi`

##### Responses

The endpoint should return this data structure:

```json
{
    "result": "ok",
    "data": [
        {
            "plate": "HMZ-140",
            "car_brand": "Audi",
            "car_model": "A8",
            "year": 2016,
            "color": "red"
        },
        {
            "plate": "HMZ-555",
            "car_brand": "BMZ",
            "car_model": "Z4",
            "year": 2011,
            "color": "pink"
        }
    ]
}
```

## Question

Given the following table named `carsForSale`

| carForSaleID | manufacturerName | modelName | acquisitionPrice | dataAcquired |
|:------------:|:----------------:|:---------:|:----------------:|:------------:|
|      1       |    Volkswagen    |   Jetta   |      13300       |  2007-01-07  |
|      2       |     Renault      |  Laguna   |      14700       |  2007-02-12  |
|      3       |       Ford       |   Focus   |      13600       |  2007-03-09  |
|      4       |      Daewoo      |   Tico    |       1100       |  2007-04-17  |
|      5       |      Toyota      |  Avensis  |      14500       |  2007-05-04  |
|      6       |    Alfa Romeo    |    156    |       8700       |  2007-06-23  |
|      7       |    Volkswagen    |  Passat   |      22000       |  2007-07-16  |
|      8       |     Renault      |   Clio    |       6400       |  2007-08-22  |
|      9       |       Ford       |  Fiesta   |       6900       |  2007-09-11  |
|      10      |      Daewoo      |   Cielo   |       3600       |  2007-10-18  |
|      11      |      Toyota      |   Rav4    |      24900       |  2007-11-11  |
|      12      |    Alfa Romeo    |    147    |       7500       |  2007-12-25  |
|      13      |    Volkswaen     |   Golf    |      16700       |  2008-01-14  |
|      14      |     Renault      |  Megane   |      11400       |  2008-02-24  |
|      15      |       Ford       |  Mondeo   |      14600       |  2008-03-18  |
|      16      |      Daewoo      |   Matiz   |       1700       |  2008-04-08  |
|      17      |      Toyota      |   Yaris   |       7400       |  2008-05-02  |
|      18      |    Alfa Romeo    |    159    |      17000       |  2008-06-12  |
|      19      |    Volkswagen    |   Polo    |       6500       |  2008-07-30  |
|      20      |     Renault      |  Scenic   |       6800       |  2008-08-11  |
|      21      |       Ford       |  Escort   |       2000       |  2008-09-22  |
|      22      |      Daewoo      |  Espero   |       2500       |  2008-10-09  |
|      23      |      Toyota      |  Corolla  |      103000      |  2008-11-05  |
|      24      |    Alfa Romeo    |    166    |       5200       |  2008-12-24  |

- Write an SQL query to get all `Renault` cars which are more expensive than
  8000

- Write an SQL query to decrease all `Volkswagen` car's price by 100 units

Good luck, we believe in you! 💪 💚
