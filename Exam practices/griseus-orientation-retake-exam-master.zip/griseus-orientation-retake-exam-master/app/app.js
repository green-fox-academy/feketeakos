const express = require('express');
const app = express();
const mysql = require('mysql');
app.set('view engine', 'ejs');

app.use(express.urlencoded());
app.use(express.json());
app.use(express.static('static'));

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'password',
    database: 'matrixchanger'
});

connection.connect(error => {
    if (error) {
        console.log(`cannot connect to database.`)
        return;
    }
    console.log('connection established.')
})

app.get('/', (req, res) => {
    res.sendFile('index.html', { root: 'views' });
});

app.get('/matrix/:id', (req, res) => {
    connection.query('SELECT * FROM matrices WHERE id = ?', req.params.id, (err, rows) => {
        if (err) {
            res.sendStatus(404);
            res.send({error: 'There is no matrix with this id. Please select another one.'})
        } else {
            res.json(rows)
        }
    })
});

app.put(`/matrix/:id`, (req, res) => {
    const data = req.body
    connection.query(`UPDATE matrices SET 
    'm1' = ${data.m1}, 
    'm2' = ${data.m2}, 
    'm3' = ${data.m3}, 
    'm4' = ${data.m4}, 
    'm5' = ${data.m5}, 
    'm6' = ${data.m6}, 
    'm7' = ${data.m7}, 
    'm8' = ${data.m8}, 
    'm9' = ${data.m9},
    'usable_matrix = '0')
    WHERE id = ?`, data.id, (err, rows) => {
        if (err) {
            res.sendStatus(404);
        } else {
            res.json(rows)
        }
    })
});

app.delete('/remove/:id', (req, res) => {
    connection.query('DELETE FROM matrices WHERE id = ?', req.params.id, (err, rows) => {
        if (err) {
            res.sendStatus(401);
        } else {
            res.json(rows)
        }
    })
});

module.exports = app;