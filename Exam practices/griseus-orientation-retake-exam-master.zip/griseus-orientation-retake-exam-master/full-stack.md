# 3x3 Matrix Changer

You will create a web page which can render and modify an existing 3x3 number
matrix.

## Highlights

The checking page should look like this:

![index](assets/index.png)

- It has a frontend which:
  - renders the main page with a form to get a particular matrix based on it's id
  - and another form, with 3x3 input fields and a submit button
- It has a backend which:
  - modify and save the valid matrix to a database
  - determines the `usable_matrix` field

## Database

Feel free to use [the provided SQL file](assets/matrices.sql).

## Frontend

- the **frontend** should have:
  - an input field and submit button to load a matrix
  - a heading with the title of **3x3 Matrix**
  - a heading with a nice contect
  - 3x3 input fields
  - submit button for sending the matrix to backend
- matrix is valid if
  - all the fields are filled
  - it contains only numbers

## Backend

- if the sum of the **even** numbers are between 1 and 33:
  - then the column usable_matrix in the database should be 1
  - otherwise 0
- if everything is fine save the changes in the following format:
  - id, m1, m2, m3, m4, m5, m6, m7, m8, m9, usable_matrix

## Endpoints

### GET `/`

- this endpoint should render an HTML displaying the main page

### GET `/matrix/:id`

- this endpoint sends a json with the given matrix
- if the there is no matrix with the given id this endpoint should answer back
with a 404 error code

### PUT `/matrix/:id`

- this endpoint is responsible for receiving, determining usable_matrix field
  and updating to the database
- if the there is no matrix with the given id this endpoint should answer back
  with a 401 error code

### DELETE `/remove/:id`

- this endpoint should delete the matrix with the given parameter

## Question

Given the following table named `carsForSale`

| carForSaleID | manufacturerName | modelName | acquisitionPrice | dataAcquired |
|:------------:|:----------------:|:---------:|:----------------:|:------------:|
|      1       |    Volkswagen    |   Jetta   |      13300       |  2007-01-07  |
|      2       |     Renault      |  Laguna   |      14700       |  2007-02-12  |
|      3       |       Ford       |   Focus   |      13600       |  2007-03-09  |
|      4       |      Daewoo      |   Tico    |       1100       |  2007-04-17  |
|      5       |      Toyota      |  Avensis  |      14500       |  2007-05-04  |
|      6       |    Alfa Romeo    |    156    |       8700       |  2007-06-23  |
|      7       |    Volkswagen    |  Passat   |      22000       |  2007-07-16  |
|      8       |     Renault      |   Clio    |       6400       |  2007-08-22  |
|      9       |       Ford       |  Fiesta   |       6900       |  2007-09-11  |
|      10      |      Daewoo      |   Cielo   |       3600       |  2007-10-18  |
|      11      |      Toyota      |   Rav4    |      24900       |  2007-11-11  |
|      12      |    Alfa Romeo    |    147    |       7500       |  2007-12-25  |
|      13      |    Volkswaen     |   Golf    |      16700       |  2008-01-14  |
|      14      |     Renault      |  Megane   |      11400       |  2008-02-24  |
|      15      |       Ford       |  Mondeo   |      14600       |  2008-03-18  |
|      16      |      Daewoo      |   Matiz   |       1700       |  2008-04-08  |
|      17      |      Toyota      |   Yaris   |       7400       |  2008-05-02  |
|      18      |    Alfa Romeo    |    159    |      17000       |  2008-06-12  |
|      19      |    Volkswagen    |   Polo    |       6500       |  2008-07-30  |
|      20      |     Renault      |  Scenic   |       6800       |  2008-08-11  |
|      21      |       Ford       |  Escort   |       2000       |  2008-09-22  |
|      22      |      Daewoo      |  Espero   |       2500       |  2008-10-09  |
|      23      |      Toyota      |  Corolla  |      103000      |  2008-11-05  |
|      24      |    Alfa Romeo    |    166    |       5200       |  2008-12-24  |

- Write an SQL query to get all `Renault` cars which are more expensive than
  8000
- Write an SQL query to decrease all `Volkswagen` car's price by 100 units

Good luck, we believe in you! 💪 💚
