USE master;

DROP DATABASE IF EXISTS MatrixChanger;

CREATE DATABASE MatrixChanger;

USE MatrixChanger;

CREATE TABLE matrices (
    id INT NOT NULL AUTO_INCREMENT,
    m1 TINYINT,
    m2 TINYINT,
    m3 TINYINT,
    m4 TINYINT,
    m5 TINYINT,
    m6 TINYINT,
    m7 TINYINT,
    m8 TINYINT,
    m9 TINYINT,
    usable_matrix BIT,
    PRIMARY KEY (id));

INSERT INTO matrices(m1, m2, m3, m4, m5, m6, m7, m8, m9, usable_matrix)
VALUES (1, 2, 3, 4, 5, 6, 7, 8, 9, 1),
       (5, 8, 4, 9, 2, 4, 6, 2, 3, 1),
       (8, 6, 5, 8, 5, 7, 7, 3, 9, 0);
