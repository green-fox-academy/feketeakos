# LED Playback

## Keep in mind

The exercise has to make sure about the followings:

- Compiles
- Does not have any undefined behaviour
- Does not crash
- Does not leak memory
- Does not use any blocking mechanism (like HAL_Delay() or HAL_UART_Receive())

## Exercise overview

The goal is to create a device which can read messages from UART describing sequences
of ON-OFF durations, store the sequence, and then play it back on two LEDs.

## About the data structure

Implement a **doubly linked list** to store the received data for playback.

**!!!WARNING!!! Do not name your files to list.h and list.c because it will conflict with FreeRTOS files.
Name them linked_list.h and linked_list.c instead**

The *doubly linked list* is a data structure consisting of linked **nodes**.
The first node is called **head** and the last one **tail**.
Let's call the structure which holds the tail and head pointer `list_t`.

Each node(The structure should be called `node_t`) contains some **data**, a **next**, and a **previous** pointer.
The next pointer points to the node after it, and the previous to the
node before it.
The head node's previous, and the tail node's next is a **null pointer**.

![Doubly linked list](assets/list.png)

### Structure

A node should contain the following data:

- LED: an enum which identifies the LED. The value might be GREEN or RED
- Duration: how long the event should last (in milliseconds)
- Action type: an enum that represents the action. The value might be ON or OFF

Let's call the structure that holds the above `data_t`

### Functionalities

The list should have the following functionalities:

- `list_init`: Receives a `list_t*` type as parameter and initializes it to an empty list.
- `list_push_back`: Receives a `list_t*` and a `data_t` as parameter. It should add the new data to the end of the list.
- `list_next`: Receives a `node_t*` and returns the node after it in the list. It might return NULL if it's the last element.
- `list_previous`: Receives a `node_t*` and returns the node in front of it in the list. It might return NULL if it's the first element.
- `list_empty`: Receives a `list_t*` and returns a bool whether it's empty or not.
- `list_clear`: Receives a `list_t*` and deallocates all the nodes in the list.
- `list_erase_by_greater`: Receives a `list_t*` and an integer. Deletes all the nodes from the list which is greater than the integer parameter. It should return an integer of how many nodes were deleted.

You might write additional functions if that helps you.

**Important Note**: Your functions will be used in FreeRTOS task context so you should use `pvPortMalloc` and `vPortFree` instead of `malloc` and `free` for dynamic memory allocation and deallocation.

## Embedded exercise

### Hardware setup

Connect **2 LEDs** (a red and a green one) and a **push button** to GPIO
pins on the discovery board.

Don't forget **330 ohm** current limiting resistors for the LEDs,
and a **1k ohm** pull-down resistor for the button.

The following IO pins and names should be used for the LEDs and the button:

- `RED_LED`: *D8*
- `GREEN_LED`: *D9*

- `CONTROL_BUTTON`: *D7*

### Functionalities

- The program should start in a standby state and in this state the `LED_RED` should be blinking with *2.5Hz* in a task signaling the standby status. The characters that are sent through UART should be ignored in this state.

- If the `CONTROL_BUTTON` is pushed in this state, your program should go into listening state and the `LED_RED` should stop blinking(either suspend the task or communicate with a global variable) and the `GREEN_LED` should turn on(not blink).
  - Avoid *contact_bouncing* of the button within 200ms.

- In this state your software should recieve characters on UART interface. Every time a character arrives, it should be stored in a buffer. You should do this until a null(\0) character arrives.

The playback data should be sent from the PC to the STM32 MCU via **UART**.
This data should be written manually and sent using a UART desktop tool(e.g.: Hercules).

The data should contain the following information separated by spaces:

- The **name** of the LED which might be `RED` or `GREEN`
- The **action** which might be `ON` or `OFF`
- The delay when the next action should start in **milliseconds**

For example: `RED ON 315` or `GREEN OFF 1762`

- Every time a null character(\0) arrives you should send a signal to a task which starts to parse the data in your buffer. This task should create a data_t structure and push it to the end of the list using the `list_push_back` function.
  - **After** the parsing and push back is finished, you should start waiting for another line of data so you should start fill the buffer from the beginning.
  - In case the data is not good(the name is not RED or green, the action is not ON or OFF, the number is not greater than 0), it should be ignored without pusing anything into the list. You should print `Invalid data!` on the UART then wait to the next data.
  - If you are not able to parse the data for some reason you should alternately insert `RED ON 1500` and `RED OFF 1500` and
  go on with that data. If you can parse the data, you can ignore this functionality.

Note: You might use helper functions from string.h header to make the parsing easier.

- You should print all the nodes in your list starting from the head in every 2,356 seconds displaying every node in a new line. 
  - Use TIM5 to generate callbacks instead of a task.
  - Separate different prints with a line of dashes. Example for a list with 2 nodes:

```text
RED ON 315
GREEN ON 1235
-------------
RED ON 315
GREEN ON 1235
-------------
.
.
.
```

- If the list is empty you should print: `No data`. Use the `list_empty` function.

- You can start to execute the playback in the listening state with the `CONTROL_BUTTON`.
  - You need to iterate the list node by node and execute all the actions.
  - Do not forget to turn off the `GREEN LED` before starting the playback.
  - If the `CONTROL_BUTTON` is pushed for more than 1000ms the list should be iterated backward, otherwise forward. Use the `list_next` or `list_previous` function when you iterate through the list.
  - Avoid *contact_bouncing* of the button within 200ms.
  
An example of a possible list and the action that should be done:

```text
RED ON 315 -> Turn on the RED LED and delay the next action with 315ms
GREEN ON 1235 -> Turn on the GREEN LED and delay the next action with 1235ms
GREEN OFF 472 -> Turn off the GREEN LED and delay the next action with 472ms
GREEN ON 123 -> Turn on the GREEN LED and delay the next action with 123ms
RED OFF 789 -> Turn off the RED LED and delay the next action with 789ms
RED ON 3267 -> Turn on the RED LED and delay the next action with 3267ms
```

- After the playback is finished, the list should be cleared(using the `list_clear` function) and the software should go into standby state where the `RED_LED` blinks(either resume the task or communicate with a global variable) until the next push of the `CONTROL_BUTTON` starts the next listening phase.

- If the `USER_BUTTON` is pushed in the listening state, all the nodes should be deleted where the delay is greater than 1000. Use the `list_erase_by_greater` function for this.
  - Print out how many nodes were deleted. For example: `5 nodes were deleted!`.
  - Avoid *contact_bouncing* of the button within 200ms.

#### For extra points

These functionalities are not required however you can implement them for extra points.

Implement the following function for your list:
- `list_shuffle`: Receives a `list_t` and randomly shuffles all the elements.

Implement the following functionality:
- When the `CONTROL_BUTTON` is pushed for more than 3 seconds in the listening state, the list should be shuffled before iterating it backwards to execute all the actions.