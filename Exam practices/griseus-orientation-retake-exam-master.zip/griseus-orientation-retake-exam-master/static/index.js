'use strict';
let id;

function keyup(e) {
    id = document.getElementsByTagName('input')[0].value;
}
const URL = `http://localhost:3000/matrix/${id}`;

const getButton = document.getElementsByTagName('input')[1];
const saveButton = document.getElementById('10');

window.onkeyup = keyup;


function getMatrix() {
    fetch(`/matrix/${id}`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        },
    })
        .then(response => response.json())
        .then(res => drawnumbers(res))

}

function drawnumbers(URL) {
    document.getElementById('01').value = URL[0].m1;
    document.getElementById('02').value = URL[0].m2;
    document.getElementById('03').value = URL[0].m3;
    document.getElementById('04').value = URL[0].m4;
    document.getElementById('05').value = URL[0].m5;
    document.getElementById('06').value = URL[0].m6;
    document.getElementById('07').value = URL[0].m7;
    document.getElementById('08').value = URL[0].m8;
    document.getElementById('09').value = URL[0].m9;
}

getButton.addEventListener('click', event => {
    event.preventDefault();
    getMatrix()
});


function updateMatrix() {
    fetch(`/matrix/${id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            id: id,
            m1: document.getElementById('01').value,
            m2: document.getElementById('02').value,
            m3: document.getElementById('03').value,
            m4: document.getElementById('04').value,
            m5: document.getElementById('05').value,
            m6: document.getElementById('06').value,
            m7: document.getElementById('07').value,
            m8: document.getElementById('08').value,
            m9: document.getElementById('09').value,
        })
    })
        .then(res => res.json())
}

saveButton.addEventListener('click', event => {
    event.preventDefault();
    updateMatrix()
});