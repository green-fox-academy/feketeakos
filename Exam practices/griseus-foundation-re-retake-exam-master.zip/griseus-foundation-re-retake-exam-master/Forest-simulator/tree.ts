'use strict';

export default abstract class Tree {
    height: number;

    constructor(height: number = 1) {
        this.height = height;
    }
    irrigate(): void { };

    getHeight(): number {
        return this.height;
    }
}
