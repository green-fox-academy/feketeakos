'use strict';

import Tree from './tree';
import Lumberjack from './lumberjack';
import Foxtailpine from './foxtailpine';
import Whitebarkpine from './whitebarkpine';

class Forest {
    treeList: Tree[];

    constructor(treeList: Tree[] = []) {
        this.treeList = treeList;
    }

    createForest(treeList: Tree[]): void {
        treeList.forEach(tree => {
            treeList.push(tree);
        });
    }

    rain(treeList: Tree[]): void {
        for (let i: number = 0; i < this.treeList.length; i++) {
            treeList[i].irrigate();
        }
    }

    cutTrees(lumberjack: Lumberjack): void {
        for (let i: number = 0; i < this.treeList.length; i++) {
            if (lumberjack.canCut(this.treeList[i])) {
                this.treeList.splice(i);
            }
        }
    }

    isEmpty(): boolean {
        return this.treeList.length === 0;
    }

    getStatus(): string[] {
        let statusArray: string[] = []
        for (let i: number = 0; i < this.treeList.length; i++) {
            if (this.treeList[i] instanceof Foxtailpine) {
                statusArray.push(`There is a ${this.treeList[i].height} tall FoxtailPine in the forest.`);
            } else if (this.treeList[i] instanceof Whitebarkpine) {
                statusArray.push(`There is a ${this.treeList[i].height} tall WhiteBarkPine in the forest.`);
            }
        } return statusArray;
    }
}