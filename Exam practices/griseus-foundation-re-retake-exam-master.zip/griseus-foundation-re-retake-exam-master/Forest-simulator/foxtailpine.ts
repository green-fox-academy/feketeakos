'use strict';

import Tree from './tree';

export default class Foxtailpine extends Tree {

    constructor(height: number = 1) {
        super(height);
    }
    irrigate(): void {
        this.height++;
    }
}

let myPine1: Foxtailpine = new Foxtailpine(4);
myPine1.irrigate();
console.log(myPine1.getHeight());