'use strict';

import Tree from './tree';

export default class Lumberjack {

    constructor() {
    };

    canCut(Tree: Tree): boolean {
        return Tree.height > 4;
    }
}
let lumberjack: Lumberjack = new Lumberjack();