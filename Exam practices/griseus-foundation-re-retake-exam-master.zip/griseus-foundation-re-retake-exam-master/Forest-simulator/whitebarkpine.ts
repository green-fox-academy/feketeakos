'use strict';

import Tree from './tree';

export default class Whitebarkpine extends Tree {

    constructor(height: number = 1) {
        super(height);
    }
    irrigate(): void {
        this.height = this.height + 2;
    }
}

let myPine2: Whitebarkpine = new Whitebarkpine(1);
myPine2.irrigate();
console.log(myPine2.getHeight());