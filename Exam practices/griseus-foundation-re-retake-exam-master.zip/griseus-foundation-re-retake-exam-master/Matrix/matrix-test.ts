'use strict';
import test from "tape"
import matrixTransponser from './matrix-transponse'

test(t => {
    let testMatrix: number[][] = [
        [1, 2, 3],
        [4, 5, 6],
        [7, 8, 9]
    ];
    
    let transponsedMatrix: number[][] = [
        [1, 4, 7],
        [2, 5, 8],
        [3, 6, 9]
    ];

    t.deepEqual(matrixTransponser(testMatrix), transponsedMatrix);

    t.end();
});

test(t => {
    let testMatrix2: number[][] = [
        [1, 4, 7],
        [2, 5, 8],
        [3, 6, 9]
    ];

    let transponsedMatrix2: number[][] = [
        [1, 7, 4],
        [2, 8, 5],
        [3, 9, 6]
    ];

    t.deepEqual(matrixTransponser(testMatrix2), transponsedMatrix2);

    t.end();
});