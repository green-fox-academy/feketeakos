'use strict';

let matrix1: number[][] = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
];

export default function matrixTransponser(matrix: number[][]): number[][] {
    let row = matrix.length;
    let column = matrix[0].length;
    let transponsedMatrix: number[][] = []
    for (let i: number = 0; i < column; i++) {
        let newRow: number[] = [];
        for (let j: number = 0; j < row; j++) {
            newRow.push(matrix[j][i]);
        }
        transponsedMatrix.push(newRow);
    }
    return transponsedMatrix;
}
console.log(matrixTransponser(matrix1))