# Griseus Foundation Re Retake Exam

## Getting Started

- Fork this repository under your own account
- Clone the forked repository to your computer
- Create a `.gitignore` file so generated files won't be committed
- Commit your progress frequently and with descriptive commit messages
- All your answers and solutions should go in this repository

## Keep in mind

- You can use any resource online, but **please work individually**
- **Don't just copy-paste** your answers and solutions, use your own words instead
- **Don't push your work** to GitHub until your mentor announces that the time is up

## Exercises


### Matrix transponse

Create a function that takes a matrix as a parameter and
returns the transpose of that matrix. The original matrix should remain the
same.
Keep my mind that the matrices might not be square shaped.

Write at least 2 different unit test cases.

#### Example

Input

```
[
  [1, 2, 3],
  [4, 5, 6],
  [7, 8, 9]
]
```

Output

```
[
  [1, 4, 7],
  [2, 5, 8],
  [3, 6, 9]
]
```

### The longest word

Write a method which can read and parse a file.
It should return the longest word of the file.
If multiple words are found as longest you can decide which one to return.
You can assume that words are separated by spaces only and
the words may contain non-letter characters.

#### Example

[Example file can be found here.](./tale.txt)

Output:

```
Maurisinfaucibusmassaeuscelerisqueenim.
```

### Forest simulator

You are going to model a Forest with rain and a lumberjack who cuts tall trees.

#### Tree

- Trees should have a height.
- We must be able to create trees in two ways:
  - providing `height`
  - not providing `height`, in this case the height will be 0 by default.
- It has an `irrigate` method which will increase the height of the tree.
  The implementation should depend on the type of the tree.
- It has a `getHeight` method which returns the tree's height.

##### WhitebarkPine

- This tree type grows by 2 units each time its irrigated.

##### FoxtailPine

- This tree type grows by 1 unit each time its irrigated.

#### Lumberjack

You should be able to create a lumberjack without providing any parameters.

- It has a `canCut(tree)` method which takes a tree as parameter and returns true if its taller than 4 units.

#### Forest

- It should have a list of trees.
- We should be able to create a forest by receiving a list of trees.
- It has a `rain` which should iterate through the trees and irrigate them one by one.
- It has a `cutTrees(lumberjack)` which should remove all the trees which can be cut by the lumberjack.
  (It calls the `canCut` method on the lumberjack).
- It has an `isEmpty` method which returns true if there is no tree in the forest.
- It has a `getStatus` method which returns an array/list with status reports about each tree in the forest.
  For example:

```
[
  'There is a 3 tall WhitebarkPine in the forest.',
  'There is a 2 tall WhitebarkPine in the forest.',
  'There is a 4 tall FoxtailPine in the forest.'
]
```


## Questions

### What is the difference between a function and a method?
*type your answer here (please explain with your own words, and provide an example for your answer)*

### What is the difference between the do while and while loop?
*type your answer here (please explain with your own words, and provide an example for your answer)*


