'use strict';

export { };

const fs = require("fs");

export function getLongest(fileName: string): void {
    try {
        fs.readFileSync(fileName, "utf-8");
    } catch {
        console.log("file not found");
    }
    let content = fs.readFileSync(fileName, "utf-8");
    let split: string[] = content.split(" ");
    let wordLength: number = 0;
    let longestWordPos: number = 0;
    for (let i: number = 0; i < split.length; i++) {
        if (split[i].length > wordLength) {
            wordLength = split[i].length;
            longestWordPos = split.indexOf(split[i]);
        }
    }
    console.log(`The longest word is: ` + split[longestWordPos])
}

getLongest('tale.txt');