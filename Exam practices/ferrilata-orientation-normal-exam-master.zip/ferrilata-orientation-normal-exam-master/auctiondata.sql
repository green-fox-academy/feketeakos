USE auction;

INSERT INTO itemdetails (title, expiryDate)
VALUES ("Mouse", ("2008-07-04 11:11:11"));

INSERT INTO itemdetails (title, expiryDate, highestBid)
VALUES ("Cat", ("2020-07-04 11:11:11"), 4000)

